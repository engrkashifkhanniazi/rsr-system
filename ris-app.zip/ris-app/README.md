# RIS v1.0 — RSR Intelligent System
## KFSH Safety Department — Routine Safety Rounds

---

## Deploy Steps (10 minutes)

### Step 1: API Key lein
1. https://console.anthropic.com pe jaen
2. Sign up / Login karein
3. "API Keys" > "Create Key" click karein
4. Key copy karein (sk-ant-... se shuru hogi)

### Step 2: GitHub pe upload karein
1. https://github.com pe jaen — account banain ya login karein
2. "New Repository" click karein
3. Name: `ris-app` — Private rakhein
4. Create karein
5. Is poore folder ko upload karein (upload files button)

### Step 3: Vercel pe deploy karein
1. https://vercel.com pe jaen — GitHub se login karein
2. "Add New Project" click karein
3. `ris-app` repository select karein
4. "Environment Variables" mein add karein:
   - Key: `ANTHROPIC_API_KEY`
   - Value: aapki API key (sk-ant-...)
5. "Deploy" click karein
6. 2-3 minute mein live link mil jayega!

---

## Local Test (optional)
```bash
npm install
cp .env.example .env.local
# .env.local mein apni API key daalo
npm run dev
# http://localhost:3000 open karein
```

---

## Features
- WhatsApp post paste → AI parse
- Hospital + Construction modules
- Photo upload (observation + improvement)
- Excel download with photos embedded
- RSRIC / CPIC checklist auto-fill
- Weekly summary tracking
- Mobile responsive
