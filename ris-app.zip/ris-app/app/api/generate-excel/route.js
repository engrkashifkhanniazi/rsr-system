import ExcelJS from "exceljs";

const HOSPITAL_CHECKLIST = {
  "Fire Safety": [
    "Emergency exit doors are clear of obstructions inside and outside?",
    "Emergency exit doors close and latch properly?",
    "Emergency / exit signs are illuminating and working properly?",
    "Emergency lights are in good condition and working properly?",
    "Corridors are clear of obstructions? (unattended wheel equipment, carts, materials & etc.)",
    "Fire extinguishers are identified and clear of obstructions?",
    "Fire hose cabinets are identified and clear of obstructions?",
    "Fire alarm pull stations are identified and clear of obstructions",
    "Sprinkler heads / smoke detectors are clean and intact?",
    "Automatic fire doors are not defective and in good condition?",
    "Obvious penetrations to walls / ceilings / floors, not present?",
    "Door wedged or propped open, none found?",
    "No unauthorized heat producing equipment present?",
    "Doors to soiled / clean / hazardous materials rooms closed locked?",
    "Flammables, stored appropriately?",
  ],
  "Electrical Safety": [
    "Electrical rooms are locked and secured?",
    "Electrical outlets are not damaged or loose?",
    "Multiple plugs, extension cords, adaptors and transformers are not used?",
    "All switches, receptacles and computer boxes have covers or plates?",
    "No exposed electrical wires, cords with signs of fraying or deteriorated insulation?",
  ],
  "Chemical Safety": [
    "Eye wash and shower stations are in good condition and inspected regularly?",
    "Medical gas cylinders are stored where full and empties are separated?",
    "Medical gas cylinders are restrained properly in bins, racks, or hand carts?",
    "Hazardous materials properly stored and labeled?",
    "Sharps boxes are no more than 3/4 full; syringe disposed of properly?",
    "Secondary container are labeled properly?",
    "Appropriate chemical spill kit is available?",
    "Wearing of required PPE when needed are observed?",
  ],
  "General Safety": [
    "Handrails are attached firmly to the walls?",
    "In store room, storage is organize, no boxes on the floor and storage is less than 50 cm?",
    "Improper storage or unauthorize storage, not present?",
    "Floors - tiles, carpet in good repair - no trip hazards?",
    "No electrical cords, telephone and computer wires in area that might entangle feet?",
    "Corridors and stairwell are properly illuminated?",
    "Desk, chairs, furniture in safe condition?",
    "Are safety signs such as Evacuation Plan, Emergency Reporting Procedures and etc. available and posted?",
  ],
};

const CONSTRUCTION_CHECKLIST = {
  "Fire Safety": [
    "Exits are available and clear of obstructions?",
    "Fire detection system is not tampered / covered? Fire suppression system is operational?",
    "Fire extinguishers are available, visible and unobstructed?",
    "Are temporary partitions smoke tight and built of non-combustible materials?",
    'Is "No Smoking" policy enforced in and adjacent to the construction area?',
    "Flammable and combustible load in the construction area kept at minimum and in acceptable condition?",
    "Are hot work operations such as welding, cutting, grinding and etc. properly conducted in a safe manner?",
  ],
  "General Safety": [
    "Contractors are aware on how to report an accident, safety hazards, in case of fire and how to use a fire extinguisher?",
    "Appropriate safety signs in place, clear and concise for patients, visitors, staff and workers?",
    "All areas are clean and free of debris, including scrap materials and food?",
    "Is power supply properly secured at the end of each workday?",
    "Hand and safety rails in place and in good condition?",
    "Power tools and extension cords are grounded and in good condition, GFIC used when appropriate?",
    "All utilities are maintained or temporary provisions made and in good condition?",
    "Are required PPEs properly worn by the contractor's workers?",
    "Are storage of construction's materials, tools and etc. organized?",
  ],
};

// Dark blue header style
const DARK_BLUE = "FF1F4E79";
const MED_BLUE = "FF2E5090";
const WHITE = "FFFFFFFF";
const BLACK = "FF000000";

function applyHeaderStyle(cell, text, bgColor = DARK_BLUE) {
  cell.value = text;
  cell.font = { bold: true, color: { argb: WHITE }, size: 11, name: "Arial" };
  cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: bgColor } };
  cell.alignment = { horizontal: "center", vertical: "middle", wrapText: true };
  cell.border = {
    top: { style: "thin" }, left: { style: "thin" },
    bottom: { style: "thin" }, right: { style: "thin" },
  };
}

function applyLabelStyle(cell, text) {
  cell.value = text;
  cell.font = { bold: true, size: 10, name: "Arial" };
  cell.border = {
    top: { style: "thin" }, left: { style: "thin" },
    bottom: { style: "thin" }, right: { style: "thin" },
  };
}

function applyDataStyle(cell) {
  cell.font = { size: 10, name: "Arial" };
  cell.alignment = { wrapText: true, vertical: "top" };
  cell.border = {
    top: { style: "thin" }, left: { style: "thin" },
    bottom: { style: "thin" }, right: { style: "thin" },
  };
}

export async function POST(req) {
  try {
    const { module, officer, location, date, time, observations, checklist, remarks } =
      await req.json();

    const wb = new ExcelJS.Workbook();
    wb.creator = "RIS v1.0";
    wb.created = new Date();

    const isHospital = module === "hospital";
    const checklistData = isHospital ? HOSPITAL_CHECKLIST : CONSTRUCTION_CHECKLIST;
    const sheetTitle = isHospital
      ? "ROUTINE SAFETY ROUNDS\nINSPECTION CHECKLIST"
      : "CONSTRUCTION PROJECT\nINSPECTION CHECKLIST";
    const sheetName = isHospital ? "RSRIC" : "CPIC";

    // ── SHEET 1: CHECKLIST ─────────────────────────────────
    const clWs = wb.addWorksheet(sheetName);

    // Column widths
    clWs.getColumn("A").width = 3;
    clWs.getColumn("B").width = 18;
    clWs.getColumn("C").width = 5;
    clWs.getColumn("D").width = 45;
    clWs.getColumn("E").width = 6;
    clWs.getColumn("F").width = 6;
    clWs.getColumn("G").width = 6;
    clWs.getColumn("H").width = 6;
    clWs.getColumn("I").width = 6;
    clWs.getColumn("J").width = 6;
    clWs.getColumn("K").width = 6;
    clWs.getColumn("L").width = 6;
    clWs.getColumn("M").width = 20;

    // Row 1-6: spacing
    clWs.getRow(1).height = 10;
    clWs.getRow(2).height = 50;
    clWs.getRow(3).height = 10;
    clWs.getRow(4).height = 10;
    clWs.getRow(5).height = 10;
    clWs.getRow(6).height = 10;

    // Title
    clWs.mergeCells("H2:M2");
    applyHeaderStyle(clWs.getCell("H2"), sheetTitle);
    clWs.getCell("H2").font = { bold: true, color: { argb: WHITE }, size: 14, name: "Arial" };

    // Header row 7
    clWs.getRow(7).height = 18;
    ["B7", "E7", "F7", "I7", "M7"].forEach((addr) => {
      const labels = { B7: "Date", E7: "Time", F7: isHospital ? "Location" : "Location / Project Name", I7: isHospital ? "Name" : "Officer Name", M7: "Signature" };
      applyHeaderStyle(clWs.getCell(addr), labels[addr], MED_BLUE);
    });

    // Data row 8
    clWs.getRow(8).height = 22;
    clWs.getCell("B8").value = date ? new Date(date) : new Date();
    clWs.getCell("B8").numFmt = "DD/MM/YYYY";
    clWs.getCell("E8").value = time || "";
    clWs.getCell("F8").value = location;
    clWs.mergeCells("F8:H8");
    clWs.getCell("I8").value = officer;
    ["B8","E8","F8","I8","M8"].forEach(a => applyDataStyle(clWs.getCell(a)));

    // Checklist header row 10
    clWs.getRow(10).height = 18;
    applyHeaderStyle(clWs.getCell("B10"), "Descriptions", MED_BLUE);
    applyHeaderStyle(clWs.getCell("J10"), "Yes", MED_BLUE);
    applyHeaderStyle(clWs.getCell("K10"), "No", MED_BLUE);
    applyHeaderStyle(clWs.getCell("L10"), "N/a", MED_BLUE);
    applyHeaderStyle(clWs.getCell("M10"), "Comments", MED_BLUE);

    // Checklist items starting row 11
    let r = 11;
    Object.entries(checklistData).forEach(([cat, items]) => {
      clWs.getRow(r).height = 16;
      clWs.getCell(`B${r}`).value = cat;
      clWs.getCell(`B${r}`).font = { bold: true, size: 11, name: "Arial", color: { argb: "FF1F4E79" } };
      r++;
      items.forEach((item, i) => {
        clWs.getRow(r).height = 30;
        clWs.getCell(`C${r}`).value = i + 1;
        clWs.getCell(`C${r}`).alignment = { horizontal: "center" };
        clWs.mergeCells(`D${r}:I${r}`);
        clWs.getCell(`D${r}`).value = item;
        clWs.getCell(`D${r}`).alignment = { wrapText: true, vertical: "middle" };
        clWs.getCell(`D${r}`).font = { size: 10, name: "Arial" };

        const val = checklist?.[cat]?.[i] || "";
        if (val === "Yes") { clWs.getCell(`J${r}`).value = "✓"; clWs.getCell(`J${r}`).font = { bold: true, color: { argb: "FF00AA44" } }; }
        if (val === "No") { clWs.getCell(`K${r}`).value = "✓"; clWs.getCell(`K${r}`).font = { bold: true, color: { argb: "FFCC0000" } }; }
        if (val === "N/a") { clWs.getCell(`L${r}`).value = "✓"; clWs.getCell(`L${r}`).font = { color: { argb: "FF888888" } }; }
        ["C","D","J","K","L","M"].forEach(c => {
          clWs.getCell(`${c}${r}`).border = { top:{style:"thin"}, left:{style:"thin"}, bottom:{style:"thin"}, right:{style:"thin"} };
        });
        r++;
      });
      r++;
    });

    // Remarks
    clWs.getCell(`B${r}`).value = `Remarks: ${remarks || ""}`;
    clWs.getCell(`B${r}`).font = { italic: true, size: 10, name: "Arial" };
    clWs.mergeCells(`B${r}:M${r}`);
    clWs.getRow(r).height = 40;

    // ── SHEET 2: OBSERVATION REPORT ────────────────────────
    const obsWs = wb.addWorksheet("OBSERVATIONS REPORT");
    obsWs.getColumn("A").width = 22;
    obsWs.getColumn("B").width = 18;
    obsWs.getColumn("C").width = 14;
    obsWs.getColumn("D").width = 22;
    obsWs.getColumn("E").width = 14;
    obsWs.getColumn("F").width = 14;

    const issueObs = observations.filter((o) => !o.is_clear);
    const clearObs = observations.filter((o) => o.is_clear);
    const allBlocks = [
      ...issueObs,
      ...(clearObs.length > 0 ? [clearObs[0]] : []),
    ];
    if (allBlocks.length === 0) {
      allBlocks.push({
        is_clear: true,
        description:
          "All Fire Fighting Equipments, Corridors, Elevators and their Lobbies, Emergency Exits and Signages are in good condition and free of any obstruction.",
        corrective_action: "",
        status: "N/A",
        obs_photo: null,
        imp_photo: null,
      });
    }

    const BLOCK = 11; // rows per observation block

    for (let bi = 0; bi < allBlocks.length; bi++) {
      const obs = allBlocks[bi];
      const s = 1 + bi * BLOCK; // start row

      // Row s: Title
      obsWs.mergeCells(`C${s}:F${s}`);
      applyHeaderStyle(obsWs.getCell(`C${s}`), "ROUTINE SAFETY ROUNDS REPORT");
      obsWs.getCell(`C${s}`).font = { bold: true, size: 13, color: { argb: WHITE }, name: "Arial" };
      obsWs.getRow(s).height = 36;

      // Row s+1: spacer
      obsWs.getRow(s + 1).height = 4;

      // Row s+2: Reported by
      obsWs.getRow(s + 2).height = 20;
      applyLabelStyle(obsWs.getCell(`A${s + 2}`), "Reported by:");
      applyDataStyle(obsWs.getCell(`B${s + 2}`));
      obsWs.getCell(`B${s + 2}`).value = officer;
      applyLabelStyle(obsWs.getCell(`C${s + 2}`), "Day / Date:");
      applyDataStyle(obsWs.getCell(`D${s + 2}`));
      obsWs.getCell(`D${s + 2}`).value = date ? new Date(date) : new Date();
      obsWs.getCell(`D${s + 2}`).numFmt = "DD/MM/YYYY";
      applyLabelStyle(obsWs.getCell(`E${s + 2}`), "Signature:");

      // Row s+3: Location
      obsWs.getRow(s + 3).height = 20;
      applyLabelStyle(obsWs.getCell(`A${s + 3}`), "Location:");
      obsWs.mergeCells(`B${s + 3}:F${s + 3}`);
      applyDataStyle(obsWs.getCell(`B${s + 3}`));
      obsWs.getCell(`B${s + 3}`).value = location;

      // Row s+4: spacer
      obsWs.getRow(s + 4).height = 4;

      // Row s+5: Photo headers
      obsWs.getRow(s + 5).height = 20;
      if (!obs.is_clear) {
        obsWs.mergeCells(`A${s + 5}:C${s + 5}`);
        applyHeaderStyle(obsWs.getCell(`A${s + 5}`), "Observation Photo", MED_BLUE);
        obsWs.mergeCells(`D${s + 5}:F${s + 5}`);
        applyHeaderStyle(obsWs.getCell(`D${s + 5}`), "Improvement Photo", MED_BLUE);
      }

      // Row s+6: Photo area (tall)
      obsWs.getRow(s + 6).height = 130;
      obsWs.mergeCells(`A${s + 6}:C${s + 6}`);
      obsWs.mergeCells(`D${s + 6}:F${s + 6}`);
      ["A","D"].forEach(c => {
        obsWs.getCell(`${c}${s+6}`).border = { top:{style:"thin"}, left:{style:"thin"}, bottom:{style:"thin"}, right:{style:"thin"} };
      });

      // Insert observation photo
      if (!obs.is_clear && obs.obs_photo) {
        try {
          const base64Data = obs.obs_photo.replace(/^data:image\/\w+;base64,/, "");
          const ext = obs.obs_photo.startsWith("data:image/png") ? "png" : "jpeg";
          const imgId = wb.addImage({ base64: base64Data, extension: ext });
          obsWs.addImage(imgId, {
            tl: { col: 0, row: s + 5 },
            br: { col: 3, row: s + 7 },
            editAs: "oneCell",
          });
        } catch (e) { console.log("Obs photo error:", e.message); }
      }

      // Insert improvement photo
      if (!obs.is_clear && obs.imp_photo) {
        try {
          const base64Data = obs.imp_photo.replace(/^data:image\/\w+;base64,/, "");
          const ext = obs.imp_photo.startsWith("data:image/png") ? "png" : "jpeg";
          const imgId = wb.addImage({ base64: base64Data, extension: ext });
          obsWs.addImage(imgId, {
            tl: { col: 3, row: s + 5 },
            br: { col: 6, row: s + 7 },
            editAs: "oneCell",
          });
        } catch (e) { console.log("Imp photo error:", e.message); }
      }

      // Row s+7: Observation label | Action label
      obsWs.getRow(s + 7).height = 18;
      obsWs.mergeCells(`A${s + 7}:C${s + 7}`);
      applyLabelStyle(obsWs.getCell(`A${s + 7}`), "Observation: (Brief description of hazardous condition)");
      obsWs.getCell(`A${s+7}`).font = { bold: true, italic: true, size: 9, name: "Arial" };
      obsWs.mergeCells(`D${s + 7}:F${s + 7}`);
      if (!obs.is_clear) {
        applyLabelStyle(obsWs.getCell(`D${s + 7}`), "Corrective Action Taken / Recommendation:");
        obsWs.getCell(`D${s+7}`).font = { bold: true, italic: true, size: 9, name: "Arial" };
      }

      // Row s+8: Observation text | Action text
      obsWs.getRow(s + 8).height = 60;
      obsWs.mergeCells(`A${s + 8}:C${s + 8}`);
      applyDataStyle(obsWs.getCell(`A${s + 8}`));
      obsWs.getCell(`A${s + 8}`).value = obs.description;
      obsWs.mergeCells(`D${s + 8}:F${s + 8}`);
      applyDataStyle(obsWs.getCell(`D${s + 8}`));
      obsWs.getCell(`D${s + 8}`).value = obs.is_clear ? "" : obs.corrective_action;

      // Row s+9: Closed out label | Remarks label
      obsWs.getRow(s + 9).height = 18;
      obsWs.mergeCells(`A${s + 9}:C${s + 9}`);
      applyLabelStyle(obsWs.getCell(`A${s + 9}`), 'Observation has been closed-out / rectified? If "No", please specify:');
      obsWs.getCell(`A${s+9}`).font = { bold: true, size: 9, name: "Arial" };
      obsWs.mergeCells(`D${s + 9}:F${s + 9}`);
      applyLabelStyle(obsWs.getCell(`D${s + 9}`), "Remarks:");

      // Row s+10: Status | Remarks value
      obsWs.getRow(s + 10).height = 28;
      obsWs.mergeCells(`A${s + 10}:C${s + 10}`);
      const statusCell = obsWs.getCell(`A${s + 10}`);
      statusCell.value = obs.is_clear
        ? "N/A — NOTHING TO BE REPORTED"
        : (obs.status || "PENDING").toUpperCase();
      statusCell.font = {
        bold: true, size: 11, name: "Arial",
        color: { argb: obs.is_clear ? "FF00AA44" : obs.status === "Rectified" ? "FF00AA44" : "FFCC6600" },
      };
      statusCell.border = { top:{style:"thin"}, left:{style:"thin"}, bottom:{style:"thin"}, right:{style:"thin"} };
      obsWs.mergeCells(`D${s + 10}:F${s + 10}`);
      applyDataStyle(obsWs.getCell(`D${s + 10}`));
      obsWs.getCell(`D${s + 10}`).value = obs.is_clear ? remarks : "";
    }

    // ── GENERATE BUFFER ────────────────────────────────────
    const buffer = await wb.xlsx.writeBuffer();

    return new Response(buffer, {
      status: 200,
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="RSR_${isHospital ? "Hospital" : "Construction"}_${date || "report"}.xlsx"`,
      },
    });
  } catch (err) {
    console.error("Excel generation error:", err);
    return Response.json({ error: err.message }, { status: 500 });
  }
}
