import Anthropic from "@anthropic-ai/sdk";

export async function POST(req) {
  try {
    const { text } = await req.json();
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

    const msg = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 1024,
      messages: [
        {
          role: "user",
          content: `Parse this KFSH safety WhatsApp post. Return ONLY valid JSON, no markdown:
{
  "officer": "name or empty string",
  "location": "location or empty string",
  "time": "e.g. 2130H or empty string",
  "is_clear": true or false,
  "observations": [
    {
      "description": "observation text",
      "corrective_action": "action taken or empty",
      "status": "Rectified or Pending"
    }
  ]
}

Rules:
- is_clear = true if post says: nothing to report, all clear, good condition, free of obstruction, NTBR, no observation, all fire fighting equipments in good condition
- is_clear = false if there are actual safety issues/observations
- Extract each observation separately

Post:
"""
${text}
"""`,
        },
      ],
    });

    const raw = msg.content[0].text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(raw);
    return Response.json({ success: true, data: parsed });
  } catch (err) {
    console.error("Parse error:", err);
    return Response.json({ success: false, error: err.message }, { status: 500 });
  }
}
