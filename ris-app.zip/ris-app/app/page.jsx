"use client";
import RISApp from "../components/RISApp";
export default function Home() {
  return <RISApp />;
}
