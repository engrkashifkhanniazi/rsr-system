export const metadata = {
  title: "RIS v1.0 — RSR Intelligent System",
  description: "KFSH Safety Department — Routine Safety Rounds",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0, background: "#0f1117" }}>
        {children}
      </body>
    </html>
  );
}
