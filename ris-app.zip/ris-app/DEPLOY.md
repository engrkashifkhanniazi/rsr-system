# RIS v1.0 — Vercel Deployment Guide

## Step 1: Files Download Karein
Upar se `ris-app.zip` download karein aur extract karein.

## Step 2: GitHub pe Upload Karein
1. github.com pe jayen — free account banayein agar nahi hai
2. "New repository" click karein
3. Name: `ris-app` — Create repository
4. Extracted folder ke andar jayen (terminal/command prompt):
```
cd ris-app
git init
git add .
git commit -m "RIS v1.0"
git branch -M main
git remote add origin https://github.com/AAPKA_USERNAME/ris-app.git
git push -u origin main
```

## Step 3: Vercel pe Deploy Karein
1. vercel.com pe jayen — "Sign up with GitHub"
2. "Add New Project" click karein
3. `ris-app` repository select karein
4. **Environment Variables** section mein yeh add karein:
   - Key: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-...` (aapki Anthropic API key)
5. "Deploy" click karein — 2 minute mein live!

## Step 4: API Key Kahan Se Milegi?
1. console.anthropic.com pe jayen
2. "API Keys" > "Create Key"
3. Copy karein aur Vercel mein paste karein

## Bas! 🎉
Aapka link kuch aisa hoga: `https://ris-app.vercel.app`
Yeh link share karein apne team ke sath — sab use kar saktay hain.

## Agar GitHub nahi chahte?
Vercel CLI se bhi deploy ho sakta hai:
```
npm i -g vercel
cd ris-app
vercel
```
Yeh automatically puchega — Enter dabate jayen.
