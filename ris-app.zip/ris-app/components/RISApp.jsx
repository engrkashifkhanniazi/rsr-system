"use client";
import { useState, useRef } from "react";
import {
  OFFICERS, HOSPITAL_LOCATIONS, CONSTRUCTION_LOCATIONS,
  CLEAR_PHRASES, HOSPITAL_CHECKLIST, CONSTRUCTION_CHECKLIST
} from "../lib/constants";

const C = {
  bg:"#0f1117",sur:"#1a1d27",sur2:"#222637",brd:"#2e3348",
  acc:"#3d6bff",grn:"#00c9a7",warn:"#f59e0b",red:"#ef4444",
  txt:"#e8eaf0",mut:"#7b82a0",dim:"#4a5070"
};

const Card=({children,style={}})=>(
  <div style={{background:C.sur,border:`1px solid ${C.brd}`,borderRadius:12,padding:20,...style}}>{children}</div>
);
const Lbl=({children})=>(
  <div style={{fontSize:10,fontWeight:700,color:C.dim,textTransform:"uppercase",letterSpacing:"0.8px",marginBottom:5}}>{children}</div>
);
const Inp=({val,set,ph,type="text"})=>(
  <input value={val} onChange={e=>set(e.target.value)} placeholder={ph} type={type}
    style={{width:"100%",background:C.sur2,border:`1px solid ${C.brd}`,borderRadius:8,padding:"10px 12px",color:C.txt,fontFamily:"inherit",fontSize:13,outline:"none"}}/>
);
const Sel=({val,set,opts,ph})=>(
  <select value={val} onChange={e=>set(e.target.value)}
    style={{width:"100%",background:C.sur2,border:`1px solid ${C.brd}`,borderRadius:8,padding:"10px 12px",color:val?C.txt:C.dim,fontFamily:"inherit",fontSize:13,outline:"none"}}>
    <option value="">{ph}</option>
    {opts.map(o=><option key={o} value={o}>{o}</option>)}
  </select>
);
const TA=({val,set,ph,rows=3})=>(
  <textarea value={val} onChange={e=>set(e.target.value)} placeholder={ph} rows={rows}
    style={{width:"100%",background:C.sur2,border:`1px solid ${C.brd}`,borderRadius:8,padding:"10px 12px",color:C.txt,fontFamily:"inherit",fontSize:13,outline:"none",resize:"vertical"}}/>
);
const Btn=({children,onClick,v="pri",dis=false,full=false,sm=false})=>{
  const vs={pri:{background:C.acc,color:"#fff"},grn:{background:C.grn,color:"#0f1117"},out:{background:"transparent",color:C.mut,border:`1px solid ${C.brd}`},red:{background:C.red+"18",color:C.red,border:`1px solid ${C.red}44`}};
  return(<button onClick={dis?undefined:onClick} style={{display:"inline-flex",alignItems:"center",gap:6,padding:sm?"7px 14px":"10px 20px",borderRadius:8,fontSize:sm?12:13,fontWeight:700,cursor:dis?"not-allowed":"pointer",border:"none",fontFamily:"inherit",opacity:dis?0.5:1,width:full?"100%":"auto",justifyContent:full?"center":"flex-start",transition:"all 0.15s",...vs[v]}}>{children}</button>);
};
const Toast=({msg,type})=>{
  if(!msg)return null;
  const col=type==="ok"?C.grn:type==="err"?C.red:C.acc;
  return(<div style={{position:"fixed",bottom:80,right:16,zIndex:999,background:C.sur,border:`1px solid ${col}`,borderRadius:10,padding:"12px 18px",color:col,fontSize:13,fontWeight:600,boxShadow:"0 8px 32px #0008",maxWidth:300}}>{type==="ok"?"✅":type==="err"?"❌":"ℹ️"} {msg}</div>);
};

function PhotoZone({label,photos,onAdd,onRemove,emoji="📷"}){
  const ref=useRef();
  const handle=files=>{Array.from(files).forEach(f=>{const r=new FileReader();r.onload=e=>onAdd({name:f.name,url:e.target.result});r.readAsDataURL(f);});};
  return(
    <div>
      <Lbl>{emoji} {label}</Lbl>
      <div onDrop={e=>{e.preventDefault();handle(e.dataTransfer.files);}} onDragOver={e=>e.preventDefault()} onClick={()=>ref.current.click()}
        style={{border:`1.5px dashed ${C.brd}`,borderRadius:8,padding:10,cursor:"pointer",background:C.bg,minHeight:70}}>
        {photos.length===0?(
          <div style={{color:C.dim,fontSize:12,textAlign:"center",paddingTop:6}}><div style={{fontSize:22}}>📁</div>Tap ya drag karo</div>
        ):(
          <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
            {photos.map((p,i)=>(
              <div key={i} style={{position:"relative",width:60,height:60}}>
                <img src={p.url} alt="" style={{width:60,height:60,objectFit:"cover",borderRadius:6,border:`2px solid ${C.brd}`}}/>
                <button onClick={ev=>{ev.stopPropagation();onRemove(i);}} style={{position:"absolute",top:-5,right:-5,width:16,height:16,background:C.red,border:"none",borderRadius:"50%",color:"#fff",fontSize:9,cursor:"pointer",fontWeight:700}}>✕</button>
              </div>
            ))}
            <div style={{width:60,height:60,borderRadius:6,border:`2px dashed ${C.brd}`,display:"flex",alignItems:"center",justifyContent:"center",color:C.mut,fontSize:22}}>+</div>
          </div>
        )}
      </div>
      <input ref={ref} type="file" accept="image/*" multiple style={{display:"none"}} onChange={e=>handle(e.target.files)}/>
    </div>
  );
}

function ObsCard({obs,idx,onChange,onRemove}){
  const [open,setOpen]=useState(true);
  const isClear=obs.is_clear;
  return(
    <div style={{background:C.bg,border:`1px solid ${isClear?C.grn+"44":C.brd}`,borderRadius:10,overflow:"hidden",marginBottom:10}}>
      <div onClick={()=>setOpen(!open)} style={{display:"flex",alignItems:"center",gap:10,padding:"11px 14px",cursor:"pointer"}}>
        <div style={{width:26,height:26,borderRadius:6,flexShrink:0,background:isClear?C.grn+"18":C.acc+"18",border:`1px solid ${isClear?C.grn+"44":C.acc+"44"}`,color:isClear?C.grn:C.acc,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:700}}>{isClear?"✓":idx+1}</div>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontSize:13,color:isClear?C.mut:C.txt,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{obs.description||"Observation likhein..."}</div>
        </div>
        <span style={{padding:"3px 9px",borderRadius:5,fontSize:10,fontWeight:700,flexShrink:0,background:isClear?C.grn+"15":C.warn+"15",color:isClear?C.grn:C.warn}}>{isClear?"✅ Clear":"⚠️ Issue"}</span>
        <span style={{color:C.dim,fontSize:11}}>{open?"▲":"▼"}</span>
      </div>
      {open&&(
        <div style={{borderTop:`1px solid ${C.brd}`,padding:14,display:"flex",flexDirection:"column",gap:12}}>
          <div><Lbl>📝 Observation</Lbl><TA val={obs.description} set={v=>onChange({...obs,description:v})} ph="Hazardous condition..." rows={2}/></div>
          {!isClear&&(
            <>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                <PhotoZone label="Observation Photo" photos={obs.obs_photos||[]} onAdd={p=>onChange({...obs,obs_photos:[...(obs.obs_photos||[]),p]})} onRemove={i=>onChange({...obs,obs_photos:(obs.obs_photos||[]).filter((_,j)=>j!==i)})} emoji="📷"/>
                <PhotoZone label="Improvement Photo" photos={obs.imp_photos||[]} onAdd={p=>onChange({...obs,imp_photos:[...(obs.imp_photos||[]),p]})} onRemove={i=>onChange({...obs,imp_photos:(obs.imp_photos||[]).filter((_,j)=>j!==i)})} emoji="✅"/>
              </div>
              <div><Lbl>🔧 Corrective Action</Lbl><TA val={obs.corrective_action} set={v=>onChange({...obs,corrective_action:v})} ph="Action taken..." rows={2}/></div>
              <div>
                <Lbl>📌 Status</Lbl>
                <div style={{display:"flex",gap:8}}>
                  {["Rectified","Pending"].map(s=>(
                    <button key={s} onClick={()=>onChange({...obs,status:s})} style={{padding:"7px 16px",borderRadius:7,fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit",border:"1.5px solid",background:obs.status===s?(s==="Rectified"?C.grn+"18":C.warn+"18"):"transparent",borderColor:obs.status===s?(s==="Rectified"?C.grn:C.warn):C.brd,color:obs.status===s?(s==="Rectified"?C.grn:C.warn):C.mut}}>{s==="Rectified"?"✅ Rectified":"⏳ Pending"}</button>
                  ))}
                </div>
              </div>
            </>
          )}
          <div style={{display:"flex",justifyContent:"flex-end"}}><Btn v="red" onClick={onRemove} sm>🗑️ Remove</Btn></div>
        </div>
      )}
    </div>
  );
}

function ChecklistPanel({module,checklist,setChecklist}){
  const data=module==="hospital"?HOSPITAL_CHECKLIST:CONSTRUCTION_CHECKLIST;
  const toggle=(cat,idx,val)=>setChecklist(prev=>{const n={...prev};if(!n[cat])n[cat]={};n[cat][idx]=val;return n;});
  return(
    <Card>
      <div style={{fontSize:14,fontWeight:700,marginBottom:4}}>📋 {module==="hospital"?"RSRIC":"CPIC"} — Checklist</div>
      <div style={{fontSize:12,color:C.mut,marginBottom:14}}>Review karein aur Yes/No/N/a select karein</div>
      {Object.entries(data).map(([cat,items])=>(
        <div key={cat} style={{marginBottom:12}}>
          <div style={{fontSize:11,fontWeight:800,color:C.acc,textTransform:"uppercase",letterSpacing:"0.8px",marginBottom:6,paddingBottom:4,borderBottom:`1px solid ${C.brd}`}}>{cat}</div>
          {items.map((item,i)=>{
            const val=checklist[cat]?.[i]||"";
            return(
              <div key={i} style={{display:"flex",alignItems:"flex-start",gap:8,padding:"7px 0",borderBottom:i<items.length-1?`1px solid ${C.brd}22`:"none"}}>
                <span style={{fontSize:10,color:C.dim,width:16,flexShrink:0,paddingTop:2}}>{i+1}</span>
                <div style={{flex:1,fontSize:11,color:C.mut,lineHeight:1.4}}>{item}</div>
                <div style={{display:"flex",gap:4,flexShrink:0}}>
                  {["Yes","No","N/a"].map(v=>(
                    <button key={v} onClick={()=>toggle(cat,i,val===v?"":v)} style={{padding:"3px 7px",borderRadius:5,fontSize:10,fontWeight:700,cursor:"pointer",border:"1.5px solid",fontFamily:"inherit",background:val===v?(v==="Yes"?C.grn+"18":v==="No"?C.red+"18":C.mut+"18"):"transparent",borderColor:val===v?(v==="Yes"?C.grn:v==="No"?C.red:C.mut):C.brd,color:val===v?(v==="Yes"?C.grn:v==="No"?C.red:C.mut):C.dim}}>{v}</button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ))}
    </Card>
  );
}

function StepsBar({step}){
  const steps=["Module","Paste & Parse","Review","Export"];
  return(
    <div style={{display:"flex",alignItems:"center",overflowX:"auto",paddingBottom:4}}>
      {steps.map((s,i)=>(
        <div key={s} style={{display:"flex",alignItems:"center"}}>
          <div style={{display:"flex",alignItems:"center",gap:6,whiteSpace:"nowrap"}}>
            <div style={{width:24,height:24,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:700,background:i<step?C.grn:i===step?C.acc:C.sur2,color:i<step?"#0f1117":i===step?"#fff":C.dim,border:`1.5px solid ${i<step?C.grn:i===step?C.acc:C.brd}`}}>{i<step?"✓":i+1}</div>
            <span style={{fontSize:12,fontWeight:500,color:i===step?C.txt:C.mut}}>{s}</span>
          </div>
          {i<steps.length-1&&<div style={{width:20,height:1.5,background:i<step?C.grn:C.brd,margin:"0 6px"}}/>}
        </div>
      ))}
    </div>
  );
}

export default function RISApp(){
  const [tab,setTab]=useState("daily");
  const [step,setStep]=useState(0);
  const [toast,setToast]=useState({msg:"",type:""});
  const [genLoading,setGenLoading]=useState(false);
  const [parsing,setParsing]=useState(false);
  const [module,setModule]=useState("");
  const [paste,setPaste]=useState("");
  const [officer,setOfficer]=useState("Kashif");
  const [location,setLocation]=useState("");
  const [date,setDate]=useState(new Date().toISOString().split("T")[0]);
  const [time,setTime]=useState("");
  const [obs,setObs]=useState([]);
  const [remarks,setRemarks]=useState("");
  const [checklist,setChecklist]=useState({});
  const [reports,setReports]=useState([]);

  const showToast=(msg,type="info")=>{setToast({msg,type});setTimeout(()=>setToast({msg:"",type:""}),3500);};
  const reset=()=>{setStep(0);setModule("");setPaste("");setOfficer("Kashif");setLocation("");setDate(new Date().toISOString().split("T")[0]);setTime("");setObs([]);setRemarks("");setChecklist({});};

  const handleParse=async()=>{
    if(!paste.trim()){showToast("WhatsApp post paste karein","err");return;}
    setParsing(true);
    try{
      const res=await fetch("/api/parse",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:paste})});
      const json=await res.json();
      if(!json.success)throw new Error(json.error);
      const data=json.data;
      if(data.officer&&OFFICERS.includes(data.officer))setOfficer(data.officer);
      if(data.location)setLocation(data.location);
      if(data.time)setTime(data.time);
      const lc=paste.toLowerCase();
      const isClearPost=CLEAR_PHRASES.some(p=>lc.includes(p));
      if(isClearPost||(data.is_clear&&(!data.observations||data.observations.length===0))){
        setObs([{is_clear:true,description:"All Fire Fighting Equipments, Corridors, Elevators and their Lobbies, Emergency Exits and Signages are in good condition and free of any obstruction.",corrective_action:"",status:"N/A",obs_photos:[],imp_photos:[]}]);
      }else{
        const parsed=(data.observations||[]).map(o=>({is_clear:false,description:o.description||"",corrective_action:o.corrective_action||"",status:o.status==="Rectified"?"Rectified":"Pending",obs_photos:[],imp_photos:[]}));
        setObs(parsed.length>0?parsed:[{is_clear:false,description:"",corrective_action:"",status:"Pending",obs_photos:[],imp_photos:[]}]);
      }
      showToast("AI ne parse kar liya!","ok");
      setStep(2);
    }catch(e){
      showToast("Error — manual fill karein","err");
      setObs([{is_clear:false,description:"",corrective_action:"",status:"Pending",obs_photos:[],imp_photos:[]}]);
      setStep(2);
    }
    setParsing(false);
  };

  const handleGenerate=async()=>{
    if(!location){showToast("Location select karein","err");return;}
    if(obs.length===0){showToast("Observation add karein","err");return;}
    setGenLoading(true);
    try{
      const obsForApi=obs.map(o=>({...o,obs_photo:o.obs_photos?.[0]?.url||null,imp_photo:o.imp_photos?.[0]?.url||null}));
      const res=await fetch("/api/generate-excel",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({module,officer,location,date,time,observations:obsForApi,checklist,remarks})});
      if(!res.ok)throw new Error("Server error");
      const blob=await res.blob();
      const url=URL.createObjectURL(blob);
      const a=document.createElement("a");
      a.href=url;
      a.download=`RSR_${module==="hospital"?"Hospital":"Construction"}_${date}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);
      setReports(prev=>[{id:Date.now(),module,officer,location,date,time,obsCount:obs.filter(o=>!o.is_clear).length,submittedAt:new Date().toLocaleString("en-GB")},...prev]);
      showToast("Excel download ho gayi!","ok");
      setStep(3);
    }catch(e){showToast("Excel generate karne mein error","err");}
    setGenLoading(false);
  };

  const locs=module==="hospital"?HOSPITAL_LOCATIONS:CONSTRUCTION_LOCATIONS;
  const tabs=[{id:"daily",label:"📋 New Report"},{id:"weekly",label:"📊 Weekly"},{id:"history",label:"🗂️ History"}];

  return(
    <div style={{background:C.bg,minHeight:"100vh",color:C.txt,fontFamily:"system-ui,-apple-system,sans-serif"}}>
      <nav style={{background:C.sur,borderBottom:`1px solid ${C.brd}`,position:"sticky",top:0,zIndex:100,display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 16px",height:54}}>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <div style={{width:30,height:30,borderRadius:7,background:"linear-gradient(135deg,#3d6bff,#00c9a7)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:15}}>🛡️</div>
          <span style={{fontWeight:800,fontSize:15}}>RIS <span style={{color:C.acc}}>v1.0</span></span>
        </div>
        <div style={{display:"flex",gap:2,background:C.bg,borderRadius:9,padding:3}}>
          {tabs.map(t=><button key={t.id} onClick={()=>{setTab(t.id);if(t.id==="daily")reset();}} style={{padding:"6px 12px",borderRadius:6,fontSize:11,fontWeight:600,cursor:"pointer",border:"none",fontFamily:"inherit",background:tab===t.id?C.sur2:"transparent",color:tab===t.id?C.txt:C.mut}}>{t.label}</button>)}
        </div>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <div style={{background:C.grn+"18",color:C.grn,border:`1px solid ${C.grn}44`,borderRadius:20,padding:"3px 8px",fontSize:10,fontWeight:700,display:"flex",alignItems:"center",gap:4}}><span style={{width:5,height:5,background:C.grn,borderRadius:"50%",display:"inline-block"}}/>AI</div>
          <div style={{width:30,height:30,borderRadius:"50%",background:"linear-gradient(135deg,#3d6bff,#7b5ea7)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:800}}>K</div>
        </div>
      </nav>

      <div style={{maxWidth:700,margin:"0 auto",padding:"18px 14px 90px"}}>

        {tab==="daily"&&(
          <div style={{display:"flex",flexDirection:"column",gap:18}}>
            <div>
              <div style={{fontSize:20,fontWeight:800}}>New RSR Report</div>
              <div style={{fontSize:12,color:C.mut,marginTop:2}}>{new Date().toLocaleDateString("en-GB",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}</div>
            </div>
            <StepsBar step={step}/>

            {step===0&&(
              <Card>
                <div style={{fontSize:14,fontWeight:700,marginBottom:14}}>🔘 Module Select Karein</div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                  {[{id:"hospital",icon:"🏥",label:"Hospital RSR",sub:"In-patient, corridors, emergency"},{id:"construction",icon:"🏗️",label:"Construction Site",sub:"Active projects, contractors"}].map(m=>(
                    <div key={m.id} onClick={()=>{setModule(m.id);setLocation("");setStep(1);}} style={{background:module===m.id?(m.id==="hospital"?C.acc+"12":C.warn+"12"):C.bg,border:`2px solid ${module===m.id?(m.id==="hospital"?C.acc:C.warn):C.brd}`,borderRadius:10,padding:16,cursor:"pointer",transition:"all 0.2s"}}>
                      <div style={{fontSize:28,marginBottom:8}}>{m.icon}</div>
                      <div style={{fontSize:14,fontWeight:700}}>{m.label}</div>
                      <div style={{fontSize:12,color:C.mut,marginTop:2}}>{m.sub}</div>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {step===1&&(
              <div style={{display:"flex",flexDirection:"column",gap:14}}>
                <Card>
                  <div style={{fontSize:14,fontWeight:700,marginBottom:12}}>👤 Officer & Location</div>
                  <div style={{display:"flex",flexDirection:"column",gap:10}}>
                    <div><Lbl>Officer Name</Lbl><Sel val={officer} set={setOfficer} opts={OFFICERS} ph="Select officer..."/></div>
                    <div><Lbl>Location</Lbl><Sel val={location} set={setLocation} opts={locs} ph="Select location..."/></div>
                    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                      <div><Lbl>Date</Lbl><Inp val={date} set={setDate} type="date"/></div>
                      <div><Lbl>Time</Lbl><Inp val={time} set={setTime} ph="2130H"/></div>
                    </div>
                  </div>
                </Card>
                <Card>
                  <div style={{fontSize:14,fontWeight:700,marginBottom:6}}>💬 WhatsApp Post Paste Karein</div>
                  <div style={{background:C.acc+"10",border:`1px solid ${C.acc}33`,borderRadius:8,padding:"10px 12px",fontSize:12,color:"#a0aed0",marginBottom:12,lineHeight:1.5}}>
                    💡 Copy karke paste karein — AI automatically observations extract karega. "Nothing to report" post mein photo section nahi aayega.
                  </div>
                  <TA val={paste} set={setPaste} rows={7} ph={"*KFSH East Hospital*\n📍 East Wing\n🕐 2130H\n\nObservation: Fire extinguisher obstructed...\nAction: Staff informed.\n\nOR:\n\nNothing to be reported. All Fire Fighting Equipments in good condition..."}/>
                  <div style={{display:"flex",gap:10,marginTop:12,flexWrap:"wrap"}}>
                    <Btn onClick={handleParse} dis={parsing}>{parsing?"⏳ Parsing...":"🤖 AI se Parse Karein"}</Btn>
                    <Btn v="out" onClick={()=>setStep(2)}>✍️ Manually Fill</Btn>
                  </div>
                </Card>
              </div>
            )}

            {step===2&&(
              <div style={{display:"flex",flexDirection:"column",gap:14}}>
                <Card>
                  <div style={{fontSize:13,fontWeight:700,marginBottom:10}}>📋 Report Details</div>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                    <div><Lbl>Officer</Lbl><Sel val={officer} set={setOfficer} opts={OFFICERS} ph="Select..."/></div>
                    <div><Lbl>Location</Lbl><Sel val={location} set={setLocation} opts={locs} ph="Select..."/></div>
                    <div><Lbl>Date</Lbl><Inp val={date} set={setDate} type="date"/></div>
                    <div><Lbl>Time</Lbl><Inp val={time} set={setTime} ph="2130H"/></div>
                  </div>
                </Card>
                <Card>
                  <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
                    <div style={{fontSize:13,fontWeight:700}}>🔍 Observations ({obs.length})</div>
                    <div style={{display:"flex",gap:8}}>
                      <Btn v="out" sm onClick={()=>setObs(p=>[...p,{is_clear:true,description:"All Fire Fighting Equipments, Corridors, Elevators and their Lobbies, Emergency Exits and Signages are in good condition and free of any obstruction.",corrective_action:"",status:"N/A",obs_photos:[],imp_photos:[]}])}>✅ Clear</Btn>
                      <Btn v="out" sm onClick={()=>setObs(p=>[...p,{is_clear:false,description:"",corrective_action:"",status:"Pending",obs_photos:[],imp_photos:[]}])}>➕ Issue</Btn>
                    </div>
                  </div>
                  {obs.length===0?<div style={{textAlign:"center",padding:24,color:C.mut,fontSize:13}}>Upar se add karein</div>
                    :obs.map((o,i)=><ObsCard key={i} obs={o} idx={i} onChange={u=>setObs(p=>p.map((x,j)=>j===i?u:x))} onRemove={()=>setObs(p=>p.filter((_,j)=>j!==i))}/>)}
                </Card>
                <ChecklistPanel module={module} checklist={checklist} setChecklist={setChecklist}/>
                <Card><Lbl>📝 General Remarks</Lbl><TA val={remarks} set={setRemarks} ph="Koi general remarks..." rows={2}/></Card>
                <div style={{display:"flex",gap:10}}>
                  <Btn v="out" onClick={()=>setStep(1)}>← Back</Btn>
                  <Btn onClick={()=>{if(!location){showToast("Location select karein","err");return;}setStep(3);}}>➡️ Export</Btn>
                </div>
              </div>
            )}

            {step===3&&(
              <div style={{display:"flex",flexDirection:"column",gap:14}}>
                <Card style={{textAlign:"center",padding:28}}>
                  <div style={{fontSize:40,marginBottom:10}}>🎉</div>
                  <div style={{fontSize:16,fontWeight:800,color:C.grn}}>Report Ready Hai!</div>
                  <div style={{fontSize:12,color:C.mut,marginTop:4}}>{location} · {date} · {officer}</div>
                  <div style={{fontSize:12,color:C.mut,marginTop:2}}>{obs.filter(o=>!o.is_clear).length} issues · {obs.filter(o=>o.status==="Rectified").length} rectified</div>
                </Card>
                <Card>
                  <div style={{fontSize:14,fontWeight:700,marginBottom:4}}>{module==="hospital"?"🏥 Hospital":"🏗️ Construction"} Excel Download</div>
                  <div style={{fontSize:12,color:C.mut,marginBottom:14,lineHeight:1.5}}>Aapke exact template format mein — {module==="hospital"?"RSRIC":"CPIC"} checklist + Observation Report with photos embedded</div>
                  <Btn v="grn" onClick={handleGenerate} dis={genLoading} full>{genLoading?"⏳ Generating...":"⬇️ Excel Download Karein"}</Btn>
                </Card>
                <Btn v="out" onClick={reset}>← Naya Report</Btn>
              </div>
            )}
          </div>
        )}

        {tab==="weekly"&&(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <div><div style={{fontSize:20,fontWeight:800}}>Weekly RSR Summary</div><div style={{fontSize:12,color:C.mut,marginTop:2}}>Current week</div></div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
              {[{label:"Total Reports",val:reports.length,color:C.txt},{label:"Hospital",val:reports.filter(r=>r.module==="hospital").length,color:C.acc},{label:"Construction",val:reports.filter(r=>r.module==="construction").length,color:C.warn},{label:"Total Issues",val:reports.reduce((a,r)=>a+r.obsCount,0),color:C.red}].map(s=>(
                <Card key={s.label} style={{padding:14}}><div style={{fontSize:10,fontWeight:700,color:C.dim,textTransform:"uppercase",letterSpacing:"0.7px"}}>{s.label}</div><div style={{fontSize:28,fontWeight:800,color:s.color,marginTop:4}}>{s.val}</div></Card>
              ))}
            </div>
            <Card>
              <div style={{fontSize:13,fontWeight:700,marginBottom:12}}>📋 Submitted Reports</div>
              {reports.length===0?<div style={{textAlign:"center",padding:24,color:C.mut,fontSize:13}}>Koi report nahi — Daily tab se submit karein</div>
                :reports.map((r,i)=>(
                  <div key={r.id} style={{display:"flex",alignItems:"center",gap:12,padding:"11px 0",borderBottom:i<reports.length-1?`1px solid ${C.brd}`:"none"}}>
                    <span style={{fontSize:20}}>{r.module==="hospital"?"🏥":"🏗️"}</span>
                    <div style={{flex:1,minWidth:0}}><div style={{fontSize:13,fontWeight:600}}>{r.location}</div><div style={{fontSize:11,color:C.mut,marginTop:1}}>{r.date} · {r.obsCount} issues · {r.officer}</div></div>
                    <span style={{padding:"3px 9px",borderRadius:5,fontSize:10,fontWeight:700,background:C.grn+"15",color:C.grn}}>✅ Done</span>
                  </div>
                ))}
            </Card>
          </div>
        )}

        {tab==="history"&&(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <div><div style={{fontSize:20,fontWeight:800}}>Report History</div><div style={{fontSize:12,color:C.mut,marginTop:2}}>Saare generated reports</div></div>
            <Card>
              {reports.length===0?<div style={{textAlign:"center",padding:32,color:C.mut}}><div style={{fontSize:32,marginBottom:8}}>📂</div><div style={{fontSize:14,fontWeight:600}}>Koi report nahi</div><div style={{fontSize:12,marginTop:4}}>Daily tab se banayein</div></div>
                :reports.map((r,i)=>(
                  <div key={r.id} style={{display:"flex",alignItems:"center",gap:12,padding:"12px 0",borderBottom:i<reports.length-1?`1px solid ${C.brd}`:"none"}}>
                    <span style={{fontSize:22}}>{r.module==="hospital"?"🏥":"🏗️"}</span>
                    <div style={{flex:1,minWidth:0}}><div style={{fontSize:13,fontWeight:600}}>{r.location}</div><div style={{fontSize:11,color:C.mut,marginTop:1}}>{r.date} · {r.officer} · {r.submittedAt}</div></div>
                    <span style={{padding:"3px 9px",borderRadius:5,fontSize:10,fontWeight:700,background:C.grn+"15",color:C.grn}}>Downloaded</span>
                  </div>
                ))}
            </Card>
          </div>
        )}
      </div>

      <div style={{position:"fixed",bottom:0,left:0,right:0,background:C.sur,borderTop:`1px solid ${C.brd}`,display:"flex",zIndex:100}}>
        {tabs.map(t=><button key={t.id} onClick={()=>{setTab(t.id);if(t.id==="daily")reset();}} style={{flex:1,padding:"12px 0",border:"none",background:"transparent",color:tab===t.id?C.acc:C.mut,fontSize:11,fontWeight:600,cursor:"pointer",fontFamily:"inherit",borderTop:`2px solid ${tab===t.id?C.acc:"transparent"}`}}>{t.label}</button>)}
      </div>

      <Toast msg={toast.msg} type={toast.type}/>
      <style>{`*{box-sizing:border-box;}input,select,textarea{color-scheme:dark;}::-webkit-scrollbar{width:4px;}::-webkit-scrollbar-thumb{background:#2e3348;border-radius:10px;}`}</style>
    </div>
  );
}
